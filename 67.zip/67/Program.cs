using System;
using System.Collections.Generic;
using System.Linq;

namespace LibraryApp
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public bool IsAvailable { get; set; } = true;
        public string? BorrowedBy { get; set; }

        public Book()
        {
            Title = string.Empty;
            Author = string.Empty;
            Year = 0;
        }

        public Book(string title, string author, int year)
        {
            Title = title;
            Author = author;
            Year = year;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Книга: {Title}, Автор: {Author}, Год: {Year}, Доступна: {(IsAvailable ? "да" : "нет")}");
        }

        public void SetTitle(string title)
        {
            Title = title;
        }
    }

    public class Reader
    {
        public string Name { get; set; }
        public string? Surname { get; set; }
        public string? PhoneNumber { get; set; }

        public Reader(string name)
        {
            Name = name;
        }

        public Reader(string name, string surname)
        {
            Name = name;
            Surname = surname;
        }

        public Reader(string name, string surname, string phoneNumber)
        {
            Name = name;
            Surname = surname;
            PhoneNumber = phoneNumber;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Читатель: {Name} {Surname ?? string.Empty}, Телефон: {PhoneNumber ?? "не указан"}");
        }
    }

    public class Library
    {
        public static int TotalBooks { get; private set; } = 0;

        private readonly List<Book> books = new();
        private readonly List<Reader> readers = new();

        public string Name { get; private set; } = "Библиотека 'Мир книг'";

        public void ShowWelcomeMessage()
        {
            Console.WriteLine($"Добро пожаловать в {Name}!");
        }

        public void AddBook(string title, string author, int year)
        {
            books.Add(new Book(title, author, year));
            TotalBooks++;
        }

        public int GetBookCount()
        {
            return books.Count;
        }

        public Book? FindBook(string title)
        {
            return books.FirstOrDefault(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
        }

        public bool IsBookAvailable(string title)
        {
            var book = FindBook(title);
            return book != null && book.IsAvailable;
        }

        public int CalculateBookAge(int year)
        {
            return DateTime.Now.Year - year;
        }

        public bool IsReaderRegistered(string name)
        {
            return readers.Any(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        public static void ShowLibraryName()
        {
            Console.WriteLine("Библиотека 'Мир книг'");
        }

        public void ShowBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Книг в библиотеке пока нет.");
                return;
            }

            Console.WriteLine("Список книг:");
            foreach (var book in books)
            {
                book.DisplayInfo();
            }
        }

        public static int CalculateFine(int overdueDays)
        {
            return overdueDays * 50;
        }

        public static int GetMaxBooks(int first, int second)
        {
            return Math.Max(first, second);
        }

        public int GetAvailableBooks()
        {
            return books.Count(book => book.IsAvailable);
        }

        public List<Book> SearchBook(string title)
        {
            return books.Where(book => book.Title.Contains(title, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public List<Book> SearchBookByAuthor(string author)
        {
            return books.Where(book => book.Author.Contains(author, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public List<Book> SearchBook(int year)
        {
            return books.Where(book => book.Year == year).ToList();
        }

        public void AddReader(string name)
        {
            readers.Add(new Reader(name));
        }

        public void AddReader(string name, string surname)
        {
            readers.Add(new Reader(name, surname));
        }

        public void AddReader(string name, string surname, string phoneNumber)
        {
            readers.Add(new Reader(name, surname, phoneNumber));
        }

        public bool ReturnBook(string title)
        {
            var book = FindBook(title);
            if (book == null)
            {
                Console.WriteLine("Книга не найдена.");
                return false;
            }

            if (book.IsAvailable)
            {
                Console.WriteLine("Эта книга уже находится в библиотеке.");
                return false;
            }

            book.IsAvailable = true;
            book.BorrowedBy = null;
            Console.WriteLine($"Книга \"{book.Title}\" возвращена в библиотеку.");
            return true;
        }

        public bool ReturnBook(string title, int overdueDays)
        {
            if (!ReturnBook(title))
            {
                return false;
            }

            int fine = CalculateFine(overdueDays);
            Console.WriteLine($"Штраф за просрочку: {fine} руб.");
            return true;
        }

        public int CountBooksRecursive(int index = 0)
        {
            if (index >= books.Count)
            {
                return 0;
            }

            return 1 + CountBooksRecursive(index + 1);
        }

        public void SortBooksByYear()
        {
            books.Sort((first, second) => first.Year.CompareTo(second.Year));
        }

        public bool BorrowBook(string title, string readerName)
        {
            if (!IsReaderRegistered(readerName))
            {
                Console.WriteLine("Читатель не зарегистрирован.");
                return false;
            }

            var book = FindBook(title);
            if (book == null)
            {
                Console.WriteLine("Книга не найдена.");
                return false;
            }

            if (!book.IsAvailable)
            {
                Console.WriteLine("Книга уже выдана.");
                return false;
            }

            book.IsAvailable = false;
            book.BorrowedBy = readerName;
            Console.WriteLine($"Книга \"{book.Title}\" выдана читателю {readerName}.");
            return true;
        }

        public void ShowStatistics()
        {
            Console.WriteLine("Статистика библиотеки:");
            Console.WriteLine($"Общее количество книг: {TotalBooks}");
            Console.WriteLine($"Количество доступных книг: {GetAvailableBooks()}");
            Console.WriteLine($"Количество выданных книг: {GetBookCount() - GetAvailableBooks()}");
            Console.WriteLine($"Количество зарегистрированных читателей: {readers.Count}");
        }

        public void ShowMenu()
        {
            Console.WriteLine("\nГлавное меню:");
            Console.WriteLine("1. Добавить книгу");
            Console.WriteLine("2. Показать все книги");
            Console.WriteLine("3. Найти книгу");
            Console.WriteLine("4. Зарегистрировать читателя");
            Console.WriteLine("5. Выдать книгу");
            Console.WriteLine("6. Вернуть книгу");
            Console.WriteLine("7. Показать статистику");
            Console.WriteLine("8. Завершить программу");
        }
    }

    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Задачи 1–25. Библиотека");

            var library = new Library();
            library.ShowWelcomeMessage();

            var book1 = new Book("Война и мир", "Л. Н. Толстой", 1869);
            var book2 = new Book("Преступление и наказание", "Ф. М. Достоевский", 1866);
            var book3 = new Book("Анна Каренина", "Л. Н. Толстой", 1877);

            book1.DisplayInfo();
            book2.DisplayInfo();
            book3.DisplayInfo();

            library.AddBook("Идиот", "Ф. М. Достоевский", 1868);
            library.AddBook("Мастер и Маргарита", "М. А. Булгаков", 1940);
            library.AddBook("Евгений Онегин", "А. С. Пушкин", 1825);

            Console.WriteLine($"Количество книг: {library.GetBookCount()}");
            Console.WriteLine($"Книга 'Идиот' доступна? {library.IsBookAvailable("Идиот")}");
            Console.WriteLine($"Возраст книги 'Евгений Онегин': {library.CalculateBookAge(1825)}");

            var found = library.FindBook("Мастер и Маргарита");
            if (found != null)
            {
                Console.WriteLine($"Найдена книга: {found.Title}");
            }
            else
            {
                Console.WriteLine("Книга не найдена.");
            }

            Console.WriteLine($"Читатель 'Иван' зарегистрирован? {library.IsReaderRegistered("Иван")}");

            Library.ShowLibraryName();
            Console.WriteLine($"Максимум: {Library.GetMaxBooks(12, 8)}");
            Console.WriteLine($"Штраф за 3 дня просрочки: {Library.CalculateFine(3)}");
            Console.WriteLine($"Всего книг из статического счётчика: {Library.TotalBooks}");

            library.AddReader("Иван", "Иванов", "+79000000001");
            library.AddReader("Мария", "Петрова");
            library.AddReader("Алексей");

            library.ShowBooks();
            Console.WriteLine("Поиск по названию:");
            foreach (var item in library.SearchBook("идиот"))
            {
                item.DisplayInfo();
            }

            Console.WriteLine("Поиск по автору:");
            foreach (var item in library.SearchBookByAuthor("толстой"))
            {
                item.DisplayInfo();
            }

            Console.WriteLine("Поиск по году:");
            foreach (var item in library.SearchBook(1868))
            {
                item.DisplayInfo();
            }

            Console.WriteLine($"Количество книг рекурсивно: {library.CountBooksRecursive()}");
            library.SortBooksByYear();
            Console.WriteLine("Книги после сортировки по году:");
            library.ShowBooks();

            library.BorrowBook("Идиот", "Иван");
            library.ShowStatistics();
            library.ReturnBook("Идиот", 2);

            Console.WriteLine("\nРабота основного меню:\n");
            bool isRunning = true;
            while (isRunning)
            {
                library.ShowMenu();
                Console.Write("Введите номер действия: ");
                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Введите название книги: ");
                        string title = Console.ReadLine() ?? string.Empty;
                        Console.Write("Введите автора: ");
                        string author = Console.ReadLine() ?? string.Empty;
                        Console.Write("Введите год издания: ");
                        int year = int.TryParse(Console.ReadLine(), out var parsedYear) ? parsedYear : 0;
                        library.AddBook(title, author, year);
                        Console.WriteLine("Книга добавлена.");
                        break;

                    case "2":
                        library.ShowBooks();
                        break;

                    case "3":
                        Console.Write("Введите название книги для поиска: ");
                        string searchTitle = Console.ReadLine() ?? string.Empty;
                        var foundBooks = library.SearchBook(searchTitle);
                        if (foundBooks.Count == 0)
                        {
                            Console.WriteLine("Книги не найдены.");
                        }
                        else
                        {
                            foreach (var item in foundBooks)
                            {
                                item.DisplayInfo();
                            }
                        }
                        break;

                    case "4":
                        Console.Write("Введите имя читателя: ");
                        string readerName = Console.ReadLine() ?? string.Empty;
                        Console.Write("Введите фамилию (необязательно): ");
                        string readerSurname = Console.ReadLine() ?? string.Empty;
                        Console.Write("Введите номер телефона (необязательно): ");
                        string phone = Console.ReadLine() ?? string.Empty;
                        if (string.IsNullOrWhiteSpace(readerSurname) && string.IsNullOrWhiteSpace(phone))
                        {
                            library.AddReader(readerName);
                        }
                        else if (!string.IsNullOrWhiteSpace(readerSurname) && string.IsNullOrWhiteSpace(phone))
                        {
                            library.AddReader(readerName, readerSurname);
                        }
                        else
                        {
                            library.AddReader(readerName, readerSurname, phone);
                        }
                        Console.WriteLine("Читатель зарегистрирован.");
                        break;

                    case "5":
                        Console.Write("Введите название книги: ");
                        string borrowTitle = Console.ReadLine() ?? string.Empty;
                        Console.Write("Введите имя читателя: ");
                        string borrowerName = Console.ReadLine() ?? string.Empty;
                        library.BorrowBook(borrowTitle, borrowerName);
                        break;

                    case "6":
                        Console.Write("Введите название книги: ");
                        string returnTitle = Console.ReadLine() ?? string.Empty;
                        Console.Write("Введите количество дней просрочки: ");
                        int overdueDays = int.TryParse(Console.ReadLine(), out var rDays) ? rDays : 0;
                        library.ReturnBook(returnTitle, overdueDays);
                        break;

                    case "7":
                        library.ShowStatistics();
                        break;

                    case "8":
                        isRunning = false;
                        Console.WriteLine("Программа завершена.");
                        break;

                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }
            }
        }
    }
}
